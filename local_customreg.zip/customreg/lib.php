<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Cleanup legacy lib functions for Moodle 5.1+
 * All hooks are now managed in db/hooks.php via namespaced static class \local_customreg\hook_handler
 */

